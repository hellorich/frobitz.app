<?php declare(strict_types = 1);
/**
 * Class representing any other known component.
 *
 * @package query-monitor
 */

class QM_Component_Other extends QM_Component {
}
